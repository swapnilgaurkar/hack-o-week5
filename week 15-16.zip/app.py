"""
Hack-O-Week Streamlit Dashboard  (neon dark edition)
Model deployment (pickle/joblib) + Neural Network from scratch (NumPy)

Run:  streamlit run app.py   (keep nn_core.py in the same folder)
"""
import io
import pickle

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import streamlit as st
from matplotlib.colors import LinearSegmentedColormap
from sklearn.datasets import make_circles, make_moons
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

from nn_core import (Adam, NeuralNetwork, SGD, bce, gradient_check, relu, relu_grad,
                     sigmoid, sigmoid_grad, tanh, tanh_grad)

st.set_page_config(page_title="NeuroLab | Hack-O-Week", page_icon="🧠", layout="wide")

# ---------------------------------------------------------------------
# Palette + global styling
# ---------------------------------------------------------------------
BG, CARD, GRID = "#0b0f1a", "#121829", "#26304a"
CYAN, PURPLE, PINK, GREEN, AMBER = "#22d3ee", "#a78bfa", "#f472b6", "#34d399", "#fbbf24"
TEXT, MUTED = "#e5e7eb", "#94a3b8"
CMAP = LinearSegmentedColormap.from_list("neon", [PINK, "#1b1330", "#0f2233", CYAN])

plt.rcParams.update({
    "figure.facecolor": CARD, "axes.facecolor": CARD, "savefig.facecolor": CARD,
    "axes.edgecolor": GRID, "axes.labelcolor": MUTED, "xtick.color": MUTED,
    "ytick.color": MUTED, "text.color": TEXT, "axes.titlecolor": TEXT,
    "axes.titleweight": "bold", "axes.titlesize": 12, "grid.color": GRID,
    "grid.alpha": 0.6, "legend.facecolor": CARD, "legend.edgecolor": GRID,
    "font.size": 10, "axes.spines.top": False, "axes.spines.right": False,
})

st.markdown(f"""
<style>
.stApp {{ background: radial-gradient(1200px 600px at 10% -10%, #1a1540 0%, {BG} 55%) fixed; color:{TEXT}; }}
[data-testid="stHeader"] {{ background: transparent; }}
[data-testid="stSidebar"] {{ background: #0d1322; border-right: 1px solid {GRID}; }}
.stApp, .stApp p, .stApp label, .stApp li, .stApp span, .stApp h1, .stApp h2, .stApp h3, .stApp h4,
[data-testid="stMarkdownContainer"], [data-testid="stWidgetLabel"] p {{ color: {TEXT}; }}
[data-testid="stCaptionContainer"] p {{ color: {MUTED}; }}
.hero {{ padding: 28px 32px; border-radius: 20px; margin-bottom: 18px;
  background: linear-gradient(120deg, rgba(34,211,238,.16), rgba(167,139,250,.16) 55%, rgba(244,114,182,.16));
  border: 1px solid {GRID}; box-shadow: 0 0 40px rgba(34,211,238,.08); }}
.hero h1 {{ margin:0; font-size: 2.3rem; font-weight: 800;
  background: linear-gradient(90deg,{CYAN},{PURPLE},{PINK}); -webkit-background-clip:text;
  -webkit-text-fill-color: transparent; }}
.hero p {{ margin:6px 0 12px 0; color:{MUTED} !important; font-size: 1.02rem; }}
.chip {{ display:inline-block; padding:3px 12px; margin:3px 6px 0 0; border-radius:999px; font-size:.78rem;
  color:{TEXT}; border:1px solid {GRID}; background: rgba(255,255,255,.04); }}
[data-testid="stMetric"] {{ background: linear-gradient(160deg,{CARD},#0f1526); border:1px solid {GRID};
  border-radius:16px; padding:14px 18px; box-shadow: 0 4px 24px rgba(0,0,0,.35); }}
[data-testid="stMetricValue"] {{ color:{CYAN}; font-weight:800; }}
[data-testid="stMetricLabel"] p {{ color:{MUTED}; }}
.stTabs [data-baseweb="tab-list"] {{ gap:6px; border-bottom:1px solid {GRID}; }}
.stTabs [data-baseweb="tab"] {{ background: rgba(255,255,255,.03); border-radius:12px 12px 0 0;
  padding:10px 18px; color:{MUTED}; }}
.stTabs [aria-selected="true"] {{ background: linear-gradient(180deg, rgba(34,211,238,.18), rgba(34,211,238,0));
  color:{CYAN} !important; border-bottom:2px solid {CYAN}; }}
.stButton > button, .stDownloadButton > button {{ border-radius:12px; border:1px solid {GRID}; color:{TEXT};
  background: rgba(255,255,255,.04); transition: all .2s; }}
.stButton > button:hover, .stDownloadButton > button:hover {{ border-color:{CYAN}; color:{CYAN};
  box-shadow:0 0 18px rgba(34,211,238,.35); transform: translateY(-1px); }}
.stButton > button[kind="primary"] {{ background: linear-gradient(90deg,#0891b2,#7c3aed); border:none; color:white;
  font-weight:700; box-shadow:0 0 22px rgba(124,58,237,.35); }}
.stButton > button[kind="primary"]:hover {{ color:white; box-shadow:0 0 30px rgba(34,211,238,.55); }}
[data-testid="stDataFrame"] {{ border:1px solid {GRID}; border-radius:12px; overflow:hidden; }}
.stProgress > div > div > div > div {{ background: linear-gradient(90deg,{CYAN},{PURPLE},{PINK}); }}
[data-testid="stExpander"] {{ border:1px solid {GRID}; border-radius:12px; background: rgba(255,255,255,.02); }}
.section-title {{ font-size:1.5rem; font-weight:800; margin: 4px 0 10px 0; }}
.arch {{ font-family: monospace; padding:10px 14px; border-radius:12px; background:{CARD};
  border:1px dashed {GRID}; color:{CYAN}; margin-bottom: 10px; }}
</style>
""", unsafe_allow_html=True)


# ---------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------
@st.cache_data
def make_data(name, n, noise, seed=42):
    if name == "Moons":
        X, y = make_moons(n_samples=n, noise=noise, random_state=seed)
    else:
        X, y = make_circles(n_samples=n, noise=noise, factor=0.5, random_state=seed)
    return train_test_split(X, y, test_size=0.2, random_state=seed)


def plot_boundary(net, X, y, title, res=250, ax=None):
    pad = 0.5
    xx, yy = np.meshgrid(
        np.linspace(X[:, 0].min() - pad, X[:, 0].max() + pad, res),
        np.linspace(X[:, 1].min() - pad, X[:, 1].max() + pad, res),
    )
    zz = net.predict_proba(np.c_[xx.ravel(), yy.ravel()]).reshape(xx.shape)
    fig = None
    if ax is None:
        fig, ax = plt.subplots(figsize=(5, 4))
    cs = ax.contourf(xx, yy, zz, levels=24, cmap=CMAP, alpha=0.9, vmin=0, vmax=1)
    ax.contour(xx, yy, zz, levels=[0.5], colors="white", linewidths=1.6)
    ax.scatter(X[:, 0], X[:, 1], c=np.where(y == 1, CYAN, PINK), edgecolors="white",
               linewidths=0.4, s=20)
    ax.set_title(title)
    ax.spines[:].set_visible(False)
    if fig is not None:
        fig.colorbar(cs, ax=ax, label="P(class 1)")
        fig.tight_layout()
    return fig


def plot_curves(loss_h, acc_h, title="Training curves", figsize=(5, 4)):
    fig, ax = plt.subplots(figsize=figsize)
    ax.plot(loss_h, color=PINK, lw=2.2, label="loss")
    ax.fill_between(range(len(loss_h)), loss_h, color=PINK, alpha=0.12)
    ax.set_xlabel("epoch"); ax.set_ylabel("BCE loss"); ax.grid(True)
    ax2 = ax.twinx()
    ax2.plot(acc_h, color=GREEN, lw=2.2, label="accuracy")
    ax2.set_ylabel("accuracy"); ax2.set_ylim(0.4, 1.02)
    ax2.spines[:].set_visible(False)
    ax.set_title(title)
    fig.tight_layout()
    return fig


def plot_architecture(layers, act):
    sizes = [2, *layers, 1]
    names = ["Input"] + [f"Hidden {i+1}\n({act})" for i in range(len(layers))] + ["Output\n(sigmoid)"]
    cap = 8
    fig, ax = plt.subplots(figsize=(8, 3.2))
    ax.axis("off")
    pos = []
    for li, n in enumerate(sizes):
        shown = min(n, cap)
        ys = np.linspace(-(shown - 1) / 2, (shown - 1) / 2, shown)
        pos.append([(li * 2.2, y) for y in ys])
    for li in range(len(pos) - 1):
        for (x1, y1) in pos[li]:
            for (x2, y2) in pos[li + 1]:
                ax.plot([x1, x2], [y1, y2], color=PURPLE, alpha=0.18, lw=0.7, zorder=1)
    cols = [CYAN] + [PURPLE] * len(layers) + [PINK]
    for li, pts in enumerate(pos):
        for (x, y) in pts:
            ax.scatter(x, y, s=170, color=cols[li], edgecolors="white", linewidths=0.8, zorder=3)
        if sizes[li] > cap:
            ax.text(pts[0][0], pts[0][1] - 0.9, f"({sizes[li]} neurons)", ha="center", color=MUTED, fontsize=8)
        ax.text(pts[0][0], max(p[1] for p in pos[0]) + 1.2 if li == 0 else
                max(p[1] for p in pts) + 1.0, names[li], ha="center", color=TEXT, fontsize=9)
    ax.set_xlim(-0.8, (len(sizes) - 1) * 2.2 + 0.8)
    fig.tight_layout()
    return fig


def make_optimizer(name, lr):
    return SGD(lr=lr) if name == "SGD" else Adam(lr=lr)


def train_model(X, y, layers, act, opt_name, lr, epochs, batch, live=None):
    """live = (curve_placeholder, boundary_placeholder, X_vis, y_vis) for animated training."""
    net = NeuralNetwork([2, *layers, 1], hidden_activation=act)
    bar = st.progress(0.0, text=f"Training with {opt_name}...")
    every = max(1, epochs // 20)

    hist_l, hist_a = [], []
    y_col = y.reshape(-1, 1)

    def cb(e, E, *_ignored):
        # History is tracked here so this works with any version of nn_core.py
        p = net.forward(X)[0]
        hist_l.append(bce(p, y_col))
        hist_a.append(float(np.mean((p > 0.5) == y_col)))
        bar.progress(e / E, text=f"{opt_name}: epoch {e}/{E} | loss {hist_l[-1]:.4f} | acc {hist_a[-1]:.3f}")
        if live is not None and (e % every == 0 or e == E):
            curve_ph, bound_ph, Xv, yv = live
            f1 = plot_curves(hist_l, hist_a, "Live training")
            curve_ph.pyplot(f1); plt.close(f1)
            f2 = plot_boundary(net, Xv, yv, f"Decision boundary @ epoch {e}", res=110)
            bound_ph.pyplot(f2); plt.close(f2)

    loss_h, acc_h = net.fit(X, y, make_optimizer(opt_name, lr), epochs=epochs,
                            batch_size=batch, callback=cb)
    bar.empty()
    return net, loss_h, acc_h


def title(text, sub=None):
    st.markdown(f'<div class="section-title">{text}</div>', unsafe_allow_html=True)
    if sub:
        st.caption(sub)


# ---------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------
st.sidebar.markdown("## ⚙️ Control Panel")
st.sidebar.markdown("**Dataset**")
ds_name = st.sidebar.selectbox("Dataset", ["Moons", "Circles"], label_visibility="collapsed")
n_samples = st.sidebar.slider("Samples", 200, 3000, 1000, 100)
noise = st.sidebar.slider("Noise", 0.0, 0.5, 0.2, 0.05)
X_train, X_test, y_train, y_test = make_data(ds_name, n_samples, noise)

st.sidebar.markdown("---\n**Network**")
n_layers = st.sidebar.slider("Hidden layers", 1, 3, 2)
layers = [st.sidebar.slider(f"Neurons in hidden layer {i+1}", 2, 64, [16, 8, 4][i], 2)
          for i in range(n_layers)]
act = st.sidebar.selectbox("Hidden activation", ["relu", "tanh"])

st.sidebar.markdown("---\n**Training**")
opt_name = st.sidebar.selectbox("Optimizer", ["Adam", "SGD"])
lr = st.sidebar.select_slider("Learning rate", [0.001, 0.003, 0.01, 0.03, 0.1, 0.3],
                              value=0.01 if opt_name == "Adam" else 0.1)
epochs = st.sidebar.slider("Epochs", 50, 600, 300, 50)
batch = st.sidebar.select_slider("Batch size", [16, 32, 64, 128, 256], value=64)

# ---------------------------------------------------------------------
# Hero
# ---------------------------------------------------------------------
st.markdown("""
<div class="hero">
  <h1>🧠 NeuroLab</h1>
  <p>A neural network built from scratch in NumPy, with model deployment, live training and optimizer battles.</p>
  <span class="chip">pickle / joblib</span><span class="chip">perceptron</span>
  <span class="chip">activations</span><span class="chip">backpropagation</span>
  <span class="chip">BCE loss</span><span class="chip">SGD</span><span class="chip">Adam</span>
</div>
""", unsafe_allow_html=True)

tabs = st.tabs(["📦 Deployment", "⚡ Perceptron & Activations", "🚀 Train Network",
                "⚔️ SGD vs Adam", "🎯 Predict & Download"])

# =====================================================================
# TAB 1: Deployment
# =====================================================================
with tabs[0]:
    title("Model deployment: pickle vs joblib",
          "Serialize a trained model to bytes so it can be reloaded later without retraining.")
    c1, c2 = st.columns(2)
    c1.info("**pickle**: Python standard library, works for almost any object.")
    c2.info("**joblib**: faster for big NumPy arrays and supports compression.")
    st.warning("Never unpickle files from untrusted sources: it can execute arbitrary code.")

    if st.button("Train RandomForest and save with pickle + joblib", type="primary"):
        rf = RandomForestClassifier(n_estimators=100, random_state=42).fit(X_train, y_train)
        pkl_bytes = pickle.dumps(rf)
        buf = io.BytesIO()
        joblib.dump(rf, buf, compress=3)
        jl_bytes = buf.getvalue()

        rf_pkl = pickle.loads(pkl_bytes)
        rf_jl = joblib.load(io.BytesIO(jl_bytes))
        same_pkl = np.array_equal(rf.predict(X_test), rf_pkl.predict(X_test))
        same_jl = np.array_equal(rf.predict(X_test), rf_jl.predict(X_test))

        m1, m2, m3 = st.columns(3)
        m1.metric("Test accuracy", f"{rf.score(X_test, y_test):.4f}")
        m2.metric("pickle size", f"{len(pkl_bytes)/1024:.0f} KB")
        m3.metric("joblib (compressed)", f"{len(jl_bytes)/1024:.0f} KB")
        st.success(f"Reload check: pickle identical = {same_pkl} | joblib identical = {same_jl}")

        fig, ax = plt.subplots(figsize=(6, 1.8))
        ax.barh(["joblib (compressed)", "pickle"], [len(jl_bytes) / 1024, len(pkl_bytes) / 1024],
                color=[CYAN, PINK], height=0.55)
        ax.set_xlabel("size (KB)"); ax.set_title("File size comparison"); ax.grid(axis="x")
        fig.tight_layout(); st.pyplot(fig); plt.close(fig)

        d1, d2 = st.columns(2)
        d1.download_button("⬇️ rf_model.pkl", pkl_bytes, "rf_model.pkl")
        d2.download_button("⬇️ rf_model.joblib", jl_bytes, "rf_model.joblib")

    with st.expander("Show code"):
        st.code(
            "import pickle, joblib\n\n"
            "# save\n"
            "with open('model.pkl', 'wb') as f:\n    pickle.dump(model, f)\n"
            "joblib.dump(model, 'model.joblib', compress=3)\n\n"
            "# load\n"
            "with open('model.pkl', 'rb') as f:\n    model = pickle.load(f)\n"
            "model = joblib.load('model.joblib')",
            language="python",
        )

# =====================================================================
# TAB 2: Perceptron & activations
# =====================================================================
with tabs[1]:
    title("Perceptron, activations and propagation")
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("**Perceptron (single neuron)**")
        st.latex(r"z = \mathbf{w}\cdot\mathbf{x} + b, \qquad a = g(z)")
        st.markdown("**Forward propagation**")
        st.latex(r"Z^{[l]} = A^{[l-1]}W^{[l]} + b^{[l]}, \quad A^{[l]} = g(Z^{[l]})")
    with c2:
        st.markdown("**Backward propagation** (sigmoid + BCE output)")
        st.latex(r"dZ^{[L]} = A^{[L]} - Y")
        st.latex(r"dW^{[l]} = \tfrac{1}{m}A^{[l-1]T}dZ^{[l]}, \quad db^{[l]} = \tfrac{1}{m}\sum dZ^{[l]}")
        st.latex(r"dZ^{[l-1]} = (dZ^{[l]}W^{[l]T}) \odot g'(Z^{[l-1]})")

    z = np.linspace(-6, 6, 400)
    s, t, r = sigmoid(z), tanh(z), relu(z)
    fig, axes = plt.subplots(1, 2, figsize=(11, 3.8))
    axes[0].plot(z, s, color=CYAN, lw=2.4, label="sigmoid")
    axes[0].plot(z, t, color=PURPLE, lw=2.4, label="tanh")
    axes[0].plot(z, r, color=PINK, lw=2.4, label="ReLU")
    axes[0].set_title("Activation functions"); axes[0].set_ylim(-1.5, 3)
    axes[0].legend(); axes[0].grid(True)
    axes[1].plot(z, sigmoid_grad(s), color=CYAN, lw=2.4, label="sigmoid'")
    axes[1].plot(z, tanh_grad(t), color=PURPLE, lw=2.4, label="tanh'")
    axes[1].plot(z, relu_grad(z), color=PINK, lw=2.4, label="ReLU'")
    axes[1].set_title("Derivatives (used in backprop)"); axes[1].legend(); axes[1].grid(True)
    fig.tight_layout(); st.pyplot(fig); plt.close(fig)

    st.markdown("#### 🎛️ Single perceptron playground")
    pc1, pc2, pc3, pc4, pc5 = st.columns(5)
    x1 = pc1.slider("x1", -2.0, 2.0, 0.5, 0.1)
    x2 = pc2.slider("x2", -2.0, 2.0, -0.3, 0.1)
    w1 = pc3.slider("w1", -3.0, 3.0, 1.0, 0.1)
    w2 = pc4.slider("w2", -3.0, 3.0, -2.0, 0.1)
    b = pc5.slider("bias b", -3.0, 3.0, 0.2, 0.1)
    zz = w1 * x1 + w2 * x2 + b
    q1, q2, q3, q4 = st.columns(4)
    q1.metric("z = w·x + b", f"{zz:.3f}")
    q2.metric("sigmoid(z)", f"{sigmoid(zz):.3f}")
    q3.metric("tanh(z)", f"{tanh(zz):.3f}")
    q4.metric("ReLU(z)", f"{relu(zz):.3f}")

# =====================================================================
# TAB 3: Train network
# =====================================================================
with tabs[2]:
    title("Train the network from scratch", "Watch the decision boundary evolve while it learns.")
    st.markdown(f'<div class="arch">2 → {" → ".join(map(str, layers))} → 1 &nbsp;|&nbsp; {act} &nbsp;|&nbsp; '
                f'{opt_name} (lr={lr}) &nbsp;|&nbsp; BCE loss</div>', unsafe_allow_html=True)
    fig = plot_architecture(layers, act)
    st.pyplot(fig); plt.close(fig)

    go = st.button("🚀 Train network (live)", type="primary")
    live_c1, live_c2 = st.columns(2)
    curve_ph, bound_ph = live_c1.empty(), live_c2.empty()

    if go:
        net, loss_h, acc_h = train_model(X_train, y_train, layers, act, opt_name, lr, epochs, batch,
                                         live=(curve_ph, bound_ph, X_test, y_test))
        st.session_state["net"] = net
        st.session_state["hist"] = (loss_h, acc_h)
        st.session_state["cfg"] = f"{opt_name}, {act}, {layers}"

    if "net" in st.session_state:
        net = st.session_state["net"]
        loss_h, acc_h = st.session_state["hist"]
        test_acc = np.mean(net.predict(X_test) == y_test)
        m1, m2, m3 = st.columns(3)
        m1.metric("Final train loss", f"{loss_h[-1]:.4f}")
        m2.metric("Final train accuracy", f"{acc_h[-1]:.4f}")
        m3.metric("Test accuracy", f"{test_acc:.4f}")
        if not go:
            fc = plot_curves(loss_h, acc_h); curve_ph.pyplot(fc); plt.close(fc)
            fb = plot_boundary(net, X_test, y_test, "Decision boundary (test data)")
            bound_ph.pyplot(fb); plt.close(fb)

        st.markdown("#### 🔬 Backpropagation gradient check")
        st.caption("Compares backprop gradients with numerical gradients (L(w+ε) − L(w−ε)) / 2ε. "
                   "Relative errors below ~1e-6 mean backprop is correct.")
        if st.button("Run gradient check"):
            chk_net = NeuralNetwork([2, *layers, 1], hidden_activation=act)
            df = gradient_check(chk_net, X_train[:30], y_train[:30])
            st.dataframe(df.style.format({"numerical": "{:.3e}", "backprop": "{:.3e}",
                                          "relative error": "{:.2e}"}), hide_index=True)
            st.success(f"Max relative error: {df['relative error'].max():.2e}")
    else:
        st.info("Set options in the sidebar, then hit **Train network**.")

# =====================================================================
# TAB 4: SGD vs Adam
# =====================================================================
with tabs[3]:
    title("Optimizer battle: SGD vs Adam")
    st.latex(r"\text{SGD: } w = w - \eta g \qquad\qquad "
             r"\text{Adam: } w = w - \eta\,\frac{\hat m}{\sqrt{\hat v}+\epsilon}")
    st.caption("Adam keeps running averages of the gradient (m) and squared gradient (v), "
               "giving each parameter its own adaptive step size.")
    cc1, cc2 = st.columns(2)
    lr_sgd = cc1.select_slider("SGD learning rate", [0.001, 0.003, 0.01, 0.03, 0.1, 0.3], value=0.1, key="lrs")
    lr_adam = cc2.select_slider("Adam learning rate", [0.001, 0.003, 0.01, 0.03, 0.1, 0.3], value=0.01, key="lra")

    if st.button("⚔️ Start battle", type="primary"):
        results = {}
        for name, l in [("SGD", lr_sgd), ("Adam", lr_adam)]:
            net, lh, ah = train_model(X_train, y_train, layers, act, name, l, epochs, batch)
            results[name] = (net, lh, ah)
        st.session_state["cmp"] = results

    if "cmp" in st.session_state:
        res = st.session_state["cmp"]
        accs = {n: float(np.mean(r[0].predict(X_test) == y_test)) for n, r in res.items()}
        winner = min(res, key=lambda n: res[n][1][-1])
        st.success(f"🏆 Lowest final loss: **{winner}** ({res[winner][1][-1]:.4f})")

        fig, ax = plt.subplots(figsize=(9, 3.8))
        for name, col in [("SGD", PINK), ("Adam", CYAN)]:
            lh = res[name][1]
            ax.plot(lh, color=col, lw=2.4, label=name)
            ax.fill_between(range(len(lh)), lh, color=col, alpha=0.10)
        ax.set_xlabel("epoch"); ax.set_ylabel("BCE loss"); ax.set_title("Loss: SGD vs Adam")
        ax.legend(); ax.grid(True)
        fig.tight_layout(); st.pyplot(fig); plt.close(fig)

        k1, k2, k3, k4 = st.columns(4)
        k1.metric("SGD final loss", f"{res['SGD'][1][-1]:.4f}")
        k2.metric("SGD test acc", f"{accs['SGD']:.4f}")
        k3.metric("Adam final loss", f"{res['Adam'][1][-1]:.4f}")
        k4.metric("Adam test acc", f"{accs['Adam']:.4f}")

        bc1, bc2 = st.columns(2)
        for col, (name, (net, _, _)) in zip([bc1, bc2], res.items()):
            f = plot_boundary(net, X_test, y_test, f"{name} decision boundary")
            col.pyplot(f); plt.close(f)

# =====================================================================
# TAB 5: Predict & download
# =====================================================================
with tabs[4]:
    title("Use the trained model")
    if "net" not in st.session_state:
        st.info("Train a network in the **Train Network** tab first.")
    else:
        net = st.session_state["net"]
        st.caption(f"Model trained with: {st.session_state['cfg']}")
        p1, p2 = st.columns(2)
        px1 = p1.slider("Feature x1", float(X_train[:, 0].min()), float(X_train[:, 0].max()), 0.0, 0.05)
        px2 = p2.slider("Feature x2", float(X_train[:, 1].min()), float(X_train[:, 1].max()), 0.0, 0.05)
        prob = float(net.predict_proba(np.array([[px1, px2]]))[0])
        r1, r2 = st.columns([1, 2])
        r1.metric("Predicted class", int(prob > 0.5))
        r1.metric("P(class 1)", f"{prob:.3f}")
        fig, ax = plt.subplots(figsize=(5.5, 4))
        plot_boundary(net, X_test, y_test, "Your point on the decision map", res=150, ax=ax)
        ax.scatter([px1], [px2], s=330, marker="*", color=AMBER, edgecolors="white", linewidths=1, zorder=5)
        fig.tight_layout(); r2.pyplot(fig); plt.close(fig)

        title("Save the trained network")
        buf = io.BytesIO()
        joblib.dump(net, buf, compress=3)
        d1, d2 = st.columns(2)
        d1.download_button("⬇️ scratch_nn.joblib", buf.getvalue(), "scratch_nn.joblib")
        d2.download_button("⬇️ scratch_nn.pkl", pickle.dumps(net), "scratch_nn.pkl")
        reloaded = joblib.load(io.BytesIO(buf.getvalue()))
        ok = np.array_equal(net.predict(X_test), reloaded.predict(X_test))
        st.success(f"Reloaded model gives identical predictions on the test set: {ok}")
