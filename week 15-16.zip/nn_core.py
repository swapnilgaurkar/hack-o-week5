"""Core NumPy neural network code (kept in its own module so saved models can be pickled/loaded reliably)."""
import numpy as np
import pandas as pd


# =====================================================================
# Core NumPy code (activations, losses, optimizers, network)
# =====================================================================
def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -500, 500)))

def sigmoid_grad(a):
    return a * (1 - a)

def relu(z):
    return np.maximum(0, z)

def relu_grad(z):
    return (z > 0).astype(float)

def tanh(z):
    return np.tanh(z)

def tanh_grad(a):
    return 1 - a ** 2

def mse(y_hat, y):
    return np.mean((y_hat - y) ** 2)

def bce(p, y, eps=1e-12):
    p = np.clip(p, eps, 1 - eps)
    return -np.mean(y * np.log(p) + (1 - y) * np.log(1 - p))


class SGD:
    def __init__(self, lr=0.1):
        self.lr = lr

    def step(self, params, grads):
        for k in params:
            params[k] -= self.lr * grads[k]


class Adam:
    def __init__(self, lr=0.01, beta1=0.9, beta2=0.999, eps=1e-8):
        self.lr, self.b1, self.b2, self.eps = lr, beta1, beta2, eps
        self.m, self.v, self.t = {}, {}, 0

    def step(self, params, grads):
        self.t += 1
        for k in params:
            if k not in self.m:
                self.m[k] = np.zeros_like(params[k])
                self.v[k] = np.zeros_like(params[k])
            self.m[k] = self.b1 * self.m[k] + (1 - self.b1) * grads[k]
            self.v[k] = self.b2 * self.v[k] + (1 - self.b2) * grads[k] ** 2
            m_hat = self.m[k] / (1 - self.b1 ** self.t)
            v_hat = self.v[k] / (1 - self.b2 ** self.t)
            params[k] -= self.lr * m_hat / (np.sqrt(v_hat) + self.eps)


class NeuralNetwork:
    """Fully connected net: hidden layers (relu/tanh) + sigmoid output."""

    def __init__(self, layer_sizes, hidden_activation="relu", seed=42):
        rng = np.random.default_rng(seed)
        self.L = len(layer_sizes) - 1
        self.act = hidden_activation
        self.params = {}
        for i in range(1, self.L + 1):
            fan_in, fan_out = layer_sizes[i - 1], layer_sizes[i]
            scale = np.sqrt(2.0 / fan_in) if self.act == "relu" else np.sqrt(1.0 / fan_in)
            self.params[f"W{i}"] = rng.standard_normal((fan_in, fan_out)) * scale
            self.params[f"b{i}"] = np.zeros((1, fan_out))

    def _g(self, z):
        return relu(z) if self.act == "relu" else tanh(z)

    def forward(self, X):
        cache = {"A0": X}
        A = X
        for i in range(1, self.L + 1):
            Z = A @ self.params[f"W{i}"] + self.params[f"b{i}"]
            A = sigmoid(Z) if i == self.L else self._g(Z)
            cache[f"Z{i}"], cache[f"A{i}"] = Z, A
        return A, cache

    def backward(self, y, cache):
        m = y.shape[0]
        grads = {}
        dZ = cache[f"A{self.L}"] - y
        for i in range(self.L, 0, -1):
            grads[f"W{i}"] = cache[f"A{i-1}"].T @ dZ / m
            grads[f"b{i}"] = dZ.sum(axis=0, keepdims=True) / m
            if i > 1:
                dA = dZ @ self.params[f"W{i}"].T
                if self.act == "relu":
                    dZ = dA * relu_grad(cache[f"Z{i-1}"])
                else:
                    dZ = dA * tanh_grad(cache[f"A{i-1}"])
        return grads

    def fit(self, X, y, optimizer, epochs=300, batch_size=64, seed=0, callback=None):
        rng = np.random.default_rng(seed)
        y = y.reshape(-1, 1)
        loss_hist, acc_hist = [], []
        for epoch in range(1, epochs + 1):
            idx = rng.permutation(len(X))
            for s in range(0, len(X), batch_size):
                b = idx[s:s + batch_size]
                _, cache = self.forward(X[b])
                grads = self.backward(y[b], cache)
                optimizer.step(self.params, grads)
            p, _ = self.forward(X)
            loss_hist.append(bce(p, y))
            acc_hist.append(np.mean((p > 0.5) == y))
            if callback:
                callback(epoch, epochs, loss_hist, acc_hist)
        return loss_hist, acc_hist

    def predict_proba(self, X):
        return self.forward(X)[0].ravel()

    def predict(self, X):
        return (self.predict_proba(X) > 0.5).astype(int)


def gradient_check(net, X, y, eps=1e-5, seed=0):
    rng = np.random.default_rng(seed)
    y = y.reshape(-1, 1)
    _, cache = net.forward(X)
    grads = net.backward(y, cache)
    rows = []
    for k in net.params:
        p = net.params[k]
        i = tuple(int(rng.integers(0, s)) for s in p.shape)
        old = p[i]
        p[i] = old + eps; lp = bce(net.forward(X)[0], y)
        p[i] = old - eps; lm = bce(net.forward(X)[0], y)
        p[i] = old
        num, ana = (lp - lm) / (2 * eps), grads[k][i]
        rel = abs(num - ana) / max(1e-8, abs(num) + abs(ana))
        rows.append({"parameter": f"{k}{list(i)}", "numerical": num,
                     "backprop": ana, "relative error": rel})
    return pd.DataFrame(rows)
