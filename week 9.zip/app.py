"""
app.py
------
Streamlit dashboard for the Student Performance Prediction project.

Run with:
    streamlit run app.py

This file ONLY handles the UI / layout. All the actual machine
learning logic (loading data, preprocessing, training, evaluation)
lives in model.py and is reused here - the exact same trained
pipeline is used on every page, including the prediction form.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import streamlit as st

from model import train_and_evaluate, make_single_prediction

# ------------------------------------------------------------------
# Page config (must be the first Streamlit command)
# ------------------------------------------------------------------
st.set_page_config(
    page_title="Student Performance Prediction",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ------------------------------------------------------------------
# Light custom styling for metric cards / headers
# ------------------------------------------------------------------
st.markdown("""
<style>
    .main-title {
        font-size: 2.3rem;
        font-weight: 800;
        margin-bottom: 0;
    }
    .sub-title {
        font-size: 1.05rem;
        color: #6b7280;
        margin-top: 0.2rem;
        margin-bottom: 1.5rem;
    }
    .metric-card {
        background: linear-gradient(135deg, #f8fafc 0%, #eef2ff 100%);
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        padding: 1.1rem 1.2rem;
        text-align: center;
        box-shadow: 0 1px 3px rgba(0,0,0,0.04);
    }
    .metric-card h3 {
        font-size: 1.7rem;
        margin: 0.15rem 0 0.1rem 0;
        color: #1e293b;
    }
    .metric-card p {
        margin: 0;
        color: #64748b;
        font-size: 0.85rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.03em;
    }
    .section-header {
        font-size: 1.35rem;
        font-weight: 700;
        margin-top: 1.2rem;
        margin-bottom: 0.6rem;
        color: #1e293b;
    }
    .result-pass {
        background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%);
        border: 1px solid #6ee7b7;
        border-radius: 16px;
        padding: 1.8rem;
        text-align: center;
        font-size: 2.2rem;
        font-weight: 800;
        color: #065f46;
    }
    .result-fail {
        background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
        border: 1px solid #fca5a5;
        border-radius: 16px;
        padding: 1.8rem;
        text-align: center;
        font-size: 2.2rem;
        font-weight: 800;
        color: #991b1b;
    }
</style>
""", unsafe_allow_html=True)


# ------------------------------------------------------------------
# Train the model ONCE and cache it. Every page reuses this same
# fitted pipeline - nothing is retrained on page switches or on the
# prediction form.
# ------------------------------------------------------------------
@st.cache_resource(show_spinner="Training model, please wait...")
def get_artifacts():
    return train_and_evaluate()

artifacts = get_artifacts()


def metric_card(label, value, col):
    col.markdown(f"""
        <div class="metric-card">
            <p>{label}</p>
            <h3>{value}</h3>
        </div>
    """, unsafe_allow_html=True)


# ------------------------------------------------------------------
# Sidebar navigation
# ------------------------------------------------------------------
st.sidebar.markdown("## 🎓 Navigation")
page = st.sidebar.radio(
    "Go to",
    ["Dashboard", "Data & Preprocessing", "Model Evaluation", "Student Prediction"],
    label_visibility="collapsed",
)

st.sidebar.markdown("---")
st.sidebar.markdown("""
**Hack-O-Week Project**
Weeks 9 & 10 · Model Evaluation +
Feature Engineering & Preprocessing

**Model:** Logistic Regression
**Dataset:** 180 student records
""")


# ==================================================================
# PAGE 1: DASHBOARD
# ==================================================================
if page == "Dashboard":
    st.markdown('<p class="main-title">🎓 Student Performance Prediction</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-title">Machine Learning Model Evaluation & Prediction Dashboard</p>', unsafe_allow_html=True)

    st.markdown('<div class="section-header">Dataset Overview</div>', unsafe_allow_html=True)
    c1, c2, c3, c4 = st.columns(4)
    metric_card("Dataset Size", "180", c1)
    metric_card("Features", "8", c2)
    metric_card("Train Samples", str(artifacts["X_train"].shape[0]), c3)
    metric_card("Test Samples", str(artifacts["X_test"].shape[0]), c4)

    st.markdown('<div class="section-header">Model Performance (Test Set)</div>', unsafe_allow_html=True)
    m = artifacts["metrics"]
    c1, c2, c3, c4, c5 = st.columns(5)
    metric_card("Test Accuracy", f"{m['accuracy']*100:.1f}%", c1)
    metric_card("Precision", f"{m['precision']*100:.1f}%", c2)
    metric_card("Recall", f"{m['recall']*100:.1f}%", c3)
    metric_card("F1 Score", f"{m['f1']*100:.1f}%", c4)
    metric_card("ROC-AUC", f"{m['roc_auc']*100:.1f}%", c5)

    st.markdown("<br>", unsafe_allow_html=True)
    st.info(
        "**About this model:** Logistic Regression is used to predict whether a "
        "student will **Pass** or **Fail** based on academic performance, "
        "attendance, and study-related features."
    )

    st.markdown('<div class="section-header">Class Distribution</div>', unsafe_allow_html=True)
    dist = artifacts["raw_df"]["Final_Result"].value_counts()
    fig, ax = plt.subplots(figsize=(5, 3))
    sns.barplot(x=dist.index, y=dist.values, hue=dist.index,
                palette={"Pass": "#34d399", "Fail": "#f87171"}, ax=ax, legend=False)
    ax.set_ylabel("Number of Students")
    ax.set_xlabel("")
    for i, v in enumerate(dist.values):
        ax.text(i, v + 1, str(v), ha="center", fontweight="bold")
    st.pyplot(fig, use_container_width=False)


# ==================================================================
# PAGE 2: DATA & PREPROCESSING
# ==================================================================
elif page == "Data & Preprocessing":
    st.markdown('<p class="main-title">📊 Data & Preprocessing</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-title">Dataset exploration, missing value handling & feature engineering</p>', unsafe_allow_html=True)

    st.markdown('<div class="section-header">Dataset Preview</div>', unsafe_allow_html=True)
    st.dataframe(artifacts["raw_df"].head(10), use_container_width=True)

    c1, c2 = st.columns(2)
    with c1:
        st.metric("Rows", artifacts["raw_df"].shape[0])
    with c2:
        st.metric("Columns", artifacts["raw_df"].shape[1])

    st.markdown('<div class="section-header">Missing Values — Before Handling</div>', unsafe_allow_html=True)
    missing_before = artifacts["missing_before"]
    mb_df = missing_before[missing_before > 0].reset_index()
    mb_df.columns = ["Column", "Missing Count"]
    col1, col2 = st.columns([1, 1])
    with col1:
        st.dataframe(mb_df, use_container_width=True, hide_index=True)
    with col2:
        fig, ax = plt.subplots(figsize=(5, 3))
        sns.barplot(data=mb_df, x="Missing Count", y="Column", color="#f59e0b", ax=ax)
        ax.set_title("Missing Values by Column")
        st.pyplot(fig, use_container_width=False)

    st.caption(
        f"Total missing values in raw dataset: **{int(missing_before.sum())}**. "
        "Numeric columns are imputed with the **median**, and the categorical "
        "column (`Extracurricular_Activity`) with the **most frequent value**. "
        "This imputation is fitted only on training data inside the pipeline "
        "(shown below is an illustrative preview on the full dataset)."
    )

    st.markdown('<div class="section-header">Missing Values — After Handling (Preview)</div>', unsafe_allow_html=True)
    after_missing = artifacts["missing_after_preview"].isnull().sum()
    st.success(f"All missing values resolved. Remaining missing values: {int(after_missing.sum())}")
    st.dataframe(artifacts["missing_after_preview"].head(10), use_container_width=True)

    st.markdown('<div class="section-header">Feature Engineering</div>', unsafe_allow_html=True)
    st.markdown("""
    **New feature created: `Average_Academic_Score`**

    `Previous_Marks`, `Assignment_Score`, and `Internal_Assessment` each capture only
    one slice of a student's academic performance. Averaging them into a single
    feature gives the model a more stable, holistic signal of overall academic
    strength, and reduces noise from any one score being an outlier (e.g. one bad
    internal exam).
    """)
    st.dataframe(
        artifacts["engineered_df"][
            ["Previous_Marks", "Assignment_Score", "Internal_Assessment", "Average_Academic_Score"]
        ].head(10),
        use_container_width=True,
    )

    st.markdown('<div class="section-header">Train / Test Split</div>', unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    total = artifacts["X_train"].shape[0] + artifacts["X_test"].shape[0]
    metric_card("Training Samples", f"{artifacts['X_train'].shape[0]} ({artifacts['X_train'].shape[0]/total*100:.0f}%)", c1)
    metric_card("Testing Samples", f"{artifacts['X_test'].shape[0]} ({artifacts['X_test'].shape[0]/total*100:.0f}%)", c2)
    metric_card("Split Type", "Stratified 80/20", c3)


# ==================================================================
# PAGE 3: MODEL EVALUATION
# ==================================================================
elif page == "Model Evaluation":
    st.markdown('<p class="main-title">📈 Model Evaluation</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-title">Confusion matrix, metrics, cross-validation & ROC curve</p>', unsafe_allow_html=True)

    m = artifacts["metrics"]
    st.markdown('<div class="section-header">Classification Metrics</div>', unsafe_allow_html=True)
    c1, c2, c3, c4, c5 = st.columns(5)
    metric_card("Accuracy", f"{m['accuracy']*100:.1f}%", c1)
    metric_card("Precision", f"{m['precision']*100:.1f}%", c2)
    metric_card("Recall", f"{m['recall']*100:.1f}%", c3)
    metric_card("F1-Score", f"{m['f1']*100:.1f}%", c4)
    metric_card("ROC-AUC", f"{m['roc_auc']*100:.1f}%", c5)

    col1, col2 = st.columns(2)

    with col1:
        st.markdown('<div class="section-header">Confusion Matrix</div>', unsafe_allow_html=True)
        cm = artifacts["confusion_matrix"]
        labels = artifacts["label_encoder"].classes_
        fig, ax = plt.subplots(figsize=(4.5, 4))
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                    xticklabels=labels, yticklabels=labels, ax=ax, cbar=False)
        ax.set_xlabel("Predicted Label")
        ax.set_ylabel("Actual Label")
        st.pyplot(fig, use_container_width=False)

    with col2:
        st.markdown('<div class="section-header">ROC Curve</div>', unsafe_allow_html=True)
        roc = artifacts["roc_curve"]
        fig, ax = plt.subplots(figsize=(4.5, 4))
        ax.plot(roc["fpr"], roc["tpr"], color="#f97316", lw=2,
                label=f"ROC Curve (AUC = {m['roc_auc']:.3f})")
        ax.plot([0, 1], [0, 1], color="#1e3a8a", lw=1, linestyle="--", label="Random Guess")
        ax.set_xlabel("False Positive Rate")
        ax.set_ylabel("True Positive Rate")
        ax.legend(loc="lower right", fontsize=8)
        st.pyplot(fig, use_container_width=False)

    st.markdown('<div class="section-header">5-Fold Cross-Validation</div>', unsafe_allow_html=True)
    cv_scores = artifacts["cv_scores"]
    cv_df = pd.DataFrame({
        "Fold": [f"Fold {i+1}" for i in range(len(cv_scores))],
        "Accuracy": np.round(cv_scores, 3)
    })
    col1, col2 = st.columns([1, 2])
    with col1:
        st.dataframe(cv_df, use_container_width=True, hide_index=True)
        st.metric("Mean CV Accuracy", f"{cv_scores.mean()*100:.1f}%", f"± {cv_scores.std()*100:.1f}%")
    with col2:
        fig, ax = plt.subplots(figsize=(5.5, 3))
        ax.bar(cv_df["Fold"], cv_df["Accuracy"], color="#6366f1")
        ax.axhline(cv_scores.mean(), color="#f97316", linestyle="--", label=f"Mean = {cv_scores.mean():.3f}")
        ax.set_ylim(0, 1)
        ax.set_ylabel("Accuracy")
        ax.legend()
        st.pyplot(fig, use_container_width=False)

    st.markdown('<div class="section-header">Classification Report</div>', unsafe_allow_html=True)
    report_df = pd.DataFrame(artifacts["classification_report"]).transpose().round(3)
    st.dataframe(report_df, use_container_width=True)


# ==================================================================
# PAGE 4: STUDENT PREDICTION
# ==================================================================
elif page == "Student Prediction":
    st.markdown('<p class="main-title">🔮 Student Prediction</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-title">Enter a student\'s details to predict Pass / Fail</p>', unsafe_allow_html=True)

    with st.form("prediction_form"):
        c1, c2 = st.columns(2)
        with c1:
            study_hours = st.slider("Study Hours (per day)", 0.5, 10.0, 4.5, 0.1)
            attendance = st.slider("Attendance (%)", 40.0, 100.0, 78.0, 0.5)
            previous_marks = st.slider("Previous Marks", 20.0, 100.0, 65.0, 0.5)
            assignment_score = st.slider("Assignment Score", 20.0, 100.0, 70.0, 0.5)
        with c2:
            internal_assessment = st.slider("Internal Assessment", 15.0, 100.0, 60.0, 0.5)
            sleep_hours = st.slider("Sleep Hours (per day)", 3.0, 10.0, 6.5, 0.1)
            extracurricular = st.selectbox("Extracurricular Activity", ["Yes", "No"])

        avg_academic_preview = round((previous_marks + assignment_score + internal_assessment) / 3, 2)
        st.caption(f"📐 Auto-calculated **Average_Academic_Score**: {avg_academic_preview}")

        submitted = st.form_submit_button("🔮 Predict Student Result", use_container_width=True)

    if submitted:
        student_input = {
            "Study_Hours": study_hours,
            "Attendance": attendance,
            "Previous_Marks": previous_marks,
            "Assignment_Score": assignment_score,
            "Internal_Assessment": internal_assessment,
            "Sleep_Hours": sleep_hours,
            "Extracurricular_Activity": extracurricular,
        }
        label, proba, row = make_single_prediction(
            artifacts["model"], artifacts["label_encoder"], artifacts["pass_index"], student_input
        )

        st.markdown("<br>", unsafe_allow_html=True)
        if label == "Pass":
            st.markdown(f'<div class="result-pass">PASS 🎉</div>', unsafe_allow_html=True)
        else:
            st.markdown(f'<div class="result-fail">FAIL ⚠️</div>', unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)
        c1, c2 = st.columns(2)
        with c1:
            st.metric("Pass Probability", f"{proba*100:.1f}%")
        with c2:
            st.metric("Fail Probability", f"{(1-proba)*100:.1f}%")

        st.progress(min(max(proba, 0.0), 1.0))

        with st.expander("View input sent to the model"):
            st.dataframe(row, use_container_width=True)
