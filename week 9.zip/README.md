# 🎓 Student Performance Prediction — Interactive Dashboard

**Hack-O-Week Project — Weeks 9 & 10**
Machine Learning Model Evaluation & Prediction Dashboard, built with **Streamlit**.

## What This Is

The same Logistic Regression ML workflow from the original terminal script
(missing value handling, feature engineering, feature scaling, train/test
split, 5-fold cross-validation, confusion matrix, precision, recall,
F1-score, ROC-AUC) — now wrapped in a polished, interactive, multi-page
web dashboard instead of console text.

**No new model is trained for the dashboard.** `model.py` trains ONE
pipeline (imputation + scaling + Logistic Regression), and every page —
including the live prediction form — reuses that exact same fitted model.

## Project Structure

```
student-performance-ml/
│
├── app.py                    # Streamlit dashboard (UI only)
├── model.py                  # All ML logic: data, preprocessing, training, evaluation
├── student_performance.csv   # Dataset (180 records, with missing values)
├── requirements.txt
└── README.md
```

## How to Install & Run (Windows / VS Code / PowerShell)

1. **Open the project folder in VS Code**, then open a PowerShell terminal
   inside VS Code (`` Ctrl + ` ``), making sure it's in the project folder.

2. **(Recommended) Create a virtual environment:**
   ```powershell
   python -m venv venv
   venv\Scripts\activate
   ```
   You should now see `(venv)` at the start of your prompt.

3. **Install the dependencies:**
   ```powershell
   pip install -r requirements.txt
   ```

4. **Run the dashboard:**
   ```powershell
   streamlit run app.py
   ```

5. Your browser should open automatically at `http://localhost:8501`.
   If not, copy that URL into your browser manually.

6. **To stop the app:** go back to the PowerShell terminal and press `Ctrl + C`.

## Pages

| Page | What it shows |
|---|---|
| **Dashboard** | Key metric cards (dataset size, split sizes, accuracy/precision/recall/F1/ROC-AUC) + class distribution chart |
| **Data & Preprocessing** | Dataset preview, missing values before/after, feature engineering explanation, train/test split |
| **Model Evaluation** | Confusion matrix heatmap, all classification metrics, 5-fold cross-validation scores, ROC curve, classification report table |
| **Student Prediction** | A form to enter a student's details and get a live Pass/Fail prediction with probability, using the same trained pipeline |

## No Data Leakage — How It's Preserved

- `model.py` builds ONE `Pipeline` combining a `ColumnTransformer`
  (median imputation + StandardScaler for numeric columns, most-frequent
  imputation + OneHotEncoder for the categorical column) with
  `LogisticRegression`.
- This pipeline is fit **only on the training split**.
- `cross_val_score` is called on the **whole pipeline**, so imputation and
  scaling are refit fresh on each fold's training portion.
- The Student Prediction page calls `model.predict()` on the **already
  trained** pipeline — it never retrains anything.

## What to Tell Your Professor on Each Page

**Dashboard page:**
"This is the overview — it shows our dataset has 180 student records split
144/36 for training and testing, and our Logistic Regression model achieves
about 81% accuracy with a strong ROC-AUC of 0.87, meaning it separates
passing and failing students well."

**Data & Preprocessing page:**
"Here I show the raw data has 38 missing values across 5 columns — this was
intentional so I could demonstrate imputation. I filled numeric gaps with
the median and the categorical gap with the most frequent value. I also
engineered a new feature, Average_Academic_Score, by combining three score
columns into one stronger signal."

**Model Evaluation page:**
"This page shows how well the model performs: the confusion matrix shows
exactly which students were correctly/incorrectly classified, the 5-fold
cross-validation confirms the model is consistent across different data
splits (not just lucky on one split), and the ROC curve with AUC = 0.87
shows strong separation between the two classes."

**Student Prediction page:**
"This is a live demo — I can enter any student's study hours, attendance,
and scores, and the same trained model will predict Pass or Fail in
real time, along with a probability score, without retraining anything."

## Notes

- The model is trained once and cached (`@st.cache_resource`), so switching
  between pages is instant — it does not retrain every time you click.
- All numbers you see (accuracy, precision, etc.) are computed live from
  the code, not hardcoded — they may shift slightly if you regenerate the
  dataset, but should stay in a similar range.
