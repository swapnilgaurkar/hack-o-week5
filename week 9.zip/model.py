"""
model.py
--------
This file contains ALL the machine learning logic for the Student
Performance Prediction project: data loading, missing value handling,
feature engineering, preprocessing pipeline, model training, cross
validation, and evaluation.

app.py (the Streamlit dashboard) imports functions from this file so
that the SAME trained pipeline is used everywhere - on the dashboard
pages AND on the prediction form. Nothing here changes the original
ML workflow; it is just organized into reusable functions instead of
top-to-bottom print statements.
"""

import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.preprocessing import StandardScaler, OneHotEncoder, LabelEncoder
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report,
    roc_curve
)

DATA_PATH = "student_performance.csv"

NUMERIC_FEATURES = [
    "Study_Hours", "Attendance", "Previous_Marks", "Assignment_Score",
    "Internal_Assessment", "Sleep_Hours", "Average_Academic_Score"
]
CATEGORICAL_FEATURES = ["Extracurricular_Activity"]


# ------------------------------------------------------------------
# STEP 2: Load dataset
# ------------------------------------------------------------------
def load_data(path: str = DATA_PATH) -> pd.DataFrame:
    return pd.read_csv(path)


# ------------------------------------------------------------------
# STEP 5: Missing value summary (before handling)
# ------------------------------------------------------------------
def missing_value_summary(df: pd.DataFrame) -> pd.Series:
    return df.isnull().sum()


# ------------------------------------------------------------------
# STEP 6: Illustrative "after imputation" preview
# (The REAL imputation used for training happens inside the Pipeline,
#  fitted only on training data - see build_preprocessing_pipeline().
#  This function only produces a preview table for the dashboard.)
# ------------------------------------------------------------------
def missing_value_preview_after(df: pd.DataFrame) -> pd.DataFrame:
    demo_df = df.copy()
    num_demo_cols = ["Study_Hours", "Attendance", "Sleep_Hours", "Assignment_Score"]
    for col in num_demo_cols:
        demo_df[col] = demo_df[col].fillna(demo_df[col].median())
    demo_df["Extracurricular_Activity"] = demo_df["Extracurricular_Activity"].fillna(
        demo_df["Extracurricular_Activity"].mode()[0]
    )
    return demo_df


# ------------------------------------------------------------------
# STEP 7: Feature Engineering
# ------------------------------------------------------------------
def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["Average_Academic_Score"] = df[
        ["Previous_Marks", "Assignment_Score", "Internal_Assessment"]
    ].mean(axis=1)
    return df


# ------------------------------------------------------------------
# STEP 11: Preprocessing pipeline (Imputation + Scaling + Encoding)
# ------------------------------------------------------------------
def build_preprocessing_pipeline() -> ColumnTransformer:
    numeric_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    categorical_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore", drop="if_binary"))
    ])
    preprocessor = ColumnTransformer(transformers=[
        ("num", numeric_transformer, NUMERIC_FEATURES),
        ("cat", categorical_transformer, CATEGORICAL_FEATURES)
    ])
    return preprocessor


# ------------------------------------------------------------------
# Full training + evaluation workflow.
# Returns one dictionary with EVERYTHING the dashboard needs, so the
# model is trained exactly ONCE (Streamlit caches this call).
# ------------------------------------------------------------------
def train_and_evaluate(path: str = DATA_PATH) -> dict:
    # Steps 2-4: load
    raw_df = load_data(path)

    # Step 5: missing values before handling
    missing_before = missing_value_summary(raw_df)

    # Step 6: illustrative preview after handling (for display only)
    missing_after_preview = missing_value_preview_after(raw_df)

    # Step 7: feature engineering
    df = engineer_features(raw_df)

    # Step 8: separate X and y
    X = df.drop(columns=["Final_Result"])
    y = df["Final_Result"]

    # Step 9: encode target
    label_encoder = LabelEncoder()
    y_encoded = label_encoder.fit_transform(y)  # Fail=0, Pass=1
    pass_index = list(label_encoder.classes_).index("Pass")

    # Step 10: train/test split (stratified)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded
    )

    # Step 11: preprocessing pipeline
    preprocessor = build_preprocessing_pipeline()

    # Step 12: model = preprocessing + Logistic Regression, in ONE pipeline
    # so imputation/scaling are fit ONLY on training data (no leakage).
    model = Pipeline(steps=[
        ("preprocessor", preprocessor),
        ("classifier", LogisticRegression(random_state=42, max_iter=1000))
    ])
    model.fit(X_train, y_train)

    # Step 13: predictions on test set
    y_pred = model.predict(X_test)
    y_pred_proba = model.predict_proba(X_test)[:, pass_index]

    # Step 14: 5-fold cross-validation (pipeline refit fresh on each fold)
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    cv_scores = cross_val_score(model, X_train, y_train, cv=cv, scoring="accuracy")

    # Step 15: metrics
    metrics = {
        "accuracy": accuracy_score(y_test, y_pred),
        "precision": precision_score(y_test, y_pred),
        "recall": recall_score(y_test, y_pred),
        "f1": f1_score(y_test, y_pred),
        "roc_auc": roc_auc_score(y_test, y_pred_proba),
    }

    # Step 16: confusion matrix
    cm = confusion_matrix(y_test, y_pred)

    # Step 17: ROC curve data
    fpr, tpr, thresholds = roc_curve(y_test, y_pred_proba)

    # Step 18: classification report (as dict, easy to turn into a table)
    report_dict = classification_report(
        y_test, y_pred, target_names=label_encoder.classes_, output_dict=True
    )

    return {
        "raw_df": raw_df,
        "engineered_df": df,
        "missing_before": missing_before,
        "missing_after_preview": missing_after_preview,
        "X_train": X_train,
        "X_test": X_test,
        "y_train": y_train,
        "y_test": y_test,
        "y_pred": y_pred,
        "y_pred_proba": y_pred_proba,
        "label_encoder": label_encoder,
        "pass_index": pass_index,
        "model": model,
        "cv_scores": cv_scores,
        "metrics": metrics,
        "confusion_matrix": cm,
        "roc_curve": {"fpr": fpr, "tpr": tpr, "thresholds": thresholds},
        "classification_report": report_dict,
    }


# ------------------------------------------------------------------
# Used by the "Student Prediction" page: build a one-row DataFrame in
# the SAME shape the pipeline was trained on, then reuse the trained
# model to predict. No retraining happens here.
# ------------------------------------------------------------------
def make_single_prediction(model, label_encoder, pass_index, student_input: dict):
    row = pd.DataFrame([{
        "Study_Hours": student_input["Study_Hours"],
        "Attendance": student_input["Attendance"],
        "Previous_Marks": student_input["Previous_Marks"],
        "Assignment_Score": student_input["Assignment_Score"],
        "Internal_Assessment": student_input["Internal_Assessment"],
        "Sleep_Hours": student_input["Sleep_Hours"],
        "Extracurricular_Activity": student_input["Extracurricular_Activity"],
    }])
    row["Average_Academic_Score"] = row[
        ["Previous_Marks", "Assignment_Score", "Internal_Assessment"]
    ].mean(axis=1)

    prediction = model.predict(row)[0]
    proba = model.predict_proba(row)[0][pass_index]
    label = label_encoder.inverse_transform([prediction])[0]

    return label, proba, row
